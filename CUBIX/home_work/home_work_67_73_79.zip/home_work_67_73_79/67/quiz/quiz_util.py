questions_and_answers= [
    (1, "What is 2 + 2?  ", 4),
    (1, 'What is "2" + "2"? ', 22),
    (1, "What is 3 / 2?  ", 1.5),
    (1, "What is 3 // 2?  ", 1),
    (1, "What is 2 ** 3?  ", 8),
    (2, "Fill missing part: a_pple ", "p")
]

