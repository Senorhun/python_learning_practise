from question_type import Question_type
import datetime

questions_and_answers= [
    (Question_type.MATH, "What is 2 + 2?  ", 4),
    (Question_type.MATH, 'What is "2" + "2"? ', 22),
    (Question_type.MATH, "What is 3 / 2?  ", 1.5),
    (Question_type.MATH, "What is 3 // 2?  ", 1),
    (Question_type.MATH, "What is 2 ** 3?  ", 8),
    (Question_type.TEXT, "What is an apple worm favorite fruit: ", "apple"),
    (Question_type.DATE, "What date was the 1000th birthday of Hungary(YYYY-MM-DD): ", datetime.date.fromisoformat("2000-08-20"))
]

