from enum import Enum

class Question_type(Enum):
    MATH = 1,
    TEXT = 2,
    DATE = 3,