questions = [
    "What is 2 + 2?  ",
    'What is "2" + "2"?  ',
    "What is 3 / 2?  ",
    "What is 3 // 2?  ",
    "What is 2 ** 3?  ",
]

answers = [
    4,
    22,
    1.5,
    1,
    8,
]