def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ValueError("Beware dividing by zero or the WORLD WILL CRUMBLE!")
    return a / b
