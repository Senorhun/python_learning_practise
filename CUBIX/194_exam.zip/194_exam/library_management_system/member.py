class Member:

    def __init__(self, name, id):
        self.name = name
        self.id = id
        self.borrowed_books = []